import { cn } from "@/lib/utils/cn";

export function Separator({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("h-px w-full bg-white/10", className)} {...props} />;
}
